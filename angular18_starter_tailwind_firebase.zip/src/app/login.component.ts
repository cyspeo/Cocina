import { Component } from '@angular/core';

@Component({
  selector: 'app-login',
  standalone: true,
  template: '<h1 class="text-2xl text-center text-gray-700">Login Page</h1>',
})
export class LoginComponent {}